package ejemploVideojuego;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nombre, genero, empresa;
        double precio;
        int pegi;
        Videojuego mivideojuego1 = new Videojuego(); // Creamos un objeto de tipo videojuego
        //Los n�meros se ponen sin las dos comillas.
        Videojuego mivideojuego2 = new Videojuego("Skyrim", "Rol", "Bethesda", 18, 10);//Dentro del parentesis llamamos a nuestros atributos
        Videojuego mivideojuego3 = new Videojuego("GTA V", "Accion", "RockstarGame", 18, 5);

        System.out.println("El nombre del juego es: " + mivideojuego2.getNombre());
        System.out.println("El genero del juego es: " + mivideojuego2.getGenero());
        System.out.println("La empresa del juego es: " + mivideojuego2.getEmpresa());
        System.out.println("El pegi del juego es: " + mivideojuego2.getPegi());
        System.out.println("El precio del juego es: " + mivideojuego2.getPrecio() + " euros ");
        System.out.println("El descuento es de " + Videojuego.descuento + " euros ");// Imprimimos en pantalla los m�todos que hace videojuego dentro del par�ntesis)

        //Con esto conseguimos si queremos cambiar el nombre del juego por uno que nosotros queramos por teclado.
        /*
        System.out.println("Introduce el nuevo nombre del juego");
        nombre = teclado.nextLine();
        mivideojuego2.setNombre(nombre);
        System.out.println("El nombre del juego es " + mivideojuego2.getNombre());

        System.out.println("Introduce el nuevo genero del juego");
        genero = teclado.nextLine();
        mivideojuego2.setGenero(genero);
        System.out.println("El nombre del juego es " + mivideojuego2.getGenero());

        System.out.println("Introduce el nombre de la nueva empresa del juego");
        empresa = teclado.nextLine();
        mivideojuego2.setEmpresa(empresa);
        System.out.println("El nombre del juego es " + mivideojuego2.getEmpresa());

        System.out.println("Introduce el nuevo pegi del juego");
        pegi = teclado.nextInt();
        mivideojuego2.setPegi(pegi);
        System.out.println("El nombre del juego es " + mivideojuego2.getNombre());

        System.out.println("Introduce el nuevo precio del juego");
        precio = teclado.nextDouble();
        mivideojuego2.setPrecio(precio);
        System.out.println("El nombre del juego es " + mivideojuego2.getNombre()); */
        
        System.out.println(mivideojuego2);
    }

}
