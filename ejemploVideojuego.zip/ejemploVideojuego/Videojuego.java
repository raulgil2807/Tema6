package ejemploVideojuego;

public class Videojuego {

    //1� Definimos los atributos que tiene nuestro videojuego
    private String nombre, genero, empresa; //Variable string para nombres.
    private int pegi;// Variable int para valores num�ricos enteros.
    private double precio; //Variable double para poner el precio en c�ntimos.

    //2� A los atributos est�ticos lo ponemos un valor que en este caso es 10.
    static int descuento = 10;

    //3� Creamos un constructor, puede ser p�blico o no puede haber nada. (Este constructor est� por defecto)
    public Videojuego() {
        //Vamos a inicializar los valores por defecto a nuestro atributos.
        //4� Si es un String se pone una cadena vacia.
        nombre = "";
        genero = "";
        empresa = "";
        //Si es un numero se inicializa como norma generla por 0.
        pegi = 0;
        precio = 0;
        //Si es un booleano se pone verdadero.

    }

    //5� Ponemos un constructor por par�metro. Y se pasa por par�metro los atributos.
    public Videojuego(String nombre, String genero, String empresa, int pegi, double precio) {
        //Usamos un puntero para indicar el atributo de mi clase, en este caso a�adimo un this.
        this.nombre = nombre; // En este caso lo que va despues del this.nombre (es nuestro atributo.)
        this.genero = genero;
        this.empresa = empresa;
        this.pegi = pegi;
        this.precio = precio;

    }

    //6� Getters sierven para llamar y poder imprimir un metodo  privado. Sir para 
    public String getNombre() {
        return nombre;
    }
    //Iniciamos con un public, luego la variable de que tipo es y a�adimos get, el atributo tiene que ser la primera en may�scula.

    public String getGenero() {
        return genero;
    }

    public String getEmpresa() {
        return empresa;
    }

    public int getPegi() {
        return pegi;
    }

    public double getPrecio() {
        return precio;
    }

    // 7� Setter es lo mismo que con el getter pero esto sirve para darle valor al metodo privado. Despues de setNombre se pone la variable a la que perternece para darle valor.
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public void setPegi(int pegi) {
        this.pegi = pegi;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    //@Override sirve para la sobrecarga el metodo para darle una nueva funcionalidad que ya existe
    @Override
    
    //Sirve para resumir e imprimir todos los m�todos en una sola vez.
    public String toString() {
        String mensaje = "Nombre: " + nombre + "\n"
                + "Genero: " + genero + "\n"
                + "Empresa: " + empresa + "\n"
                + "Precio: " + precio + " euros " + "\n"
                + "Pegi: " + pegi;
        return mensaje;

    }

}
